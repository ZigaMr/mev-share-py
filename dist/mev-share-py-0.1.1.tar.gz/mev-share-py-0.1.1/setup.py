# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mev_share_py', 'mev_share_py.api']

package_data = \
{'': ['*']}

install_requires = \
['aiohttp-sse-client>=0.2.1,<0.3.0',
 'asyncio>=3.4.3,<4.0.0',
 'black>=23.7.0,<24.0.0',
 'eth-account>=0.9.0,<0.10.0',
 'pylint>=2.17.5,<3.0.0',
 'requests>=2.31.0,<3.0.0',
 'rlp>=3.0.0,<4.0.0',
 'web3>=6.8.0,<7.0.0']

setup_kwargs = {
    'name': 'mev-share-py',
    'version': '0.1.1',
    'description': 'Python client library for interacting with flashbots mev-share node',
    'long_description': None,
    'author': 'Ziga Mrzljak',
    'author_email': 'ziga.mrzljak@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
